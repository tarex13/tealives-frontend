import React, { useEffect, useState, useRef } from 'react'
import { fetchThread, sendMessage } from '../requests'
import { formatDistanceToNow, parseISO } from 'date-fns'

function MessageThread({ userId, recipientName, currentUserId }) {
  const [messages, setMessages] = useState([])
  const [content, setContent] = useState('')
  const [typing, setTyping] = useState(false)
  const [loading, setLoading] = useState(true)
  const ws = useRef(null)
  const messagesEndRef = useRef(null)

  const token = localStorage.getItem('userToken')

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    const load = async () => {
      try {
        const res = await fetchThread(userId)
        setMessages(res)
      } catch {
        setMessages([])
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [userId])

  useEffect(() => {
    ws.current = new WebSocket(`ws://localhost:8000/ws/chat/${userId}/?token=${token}`)

    ws.current.onopen = () => console.log('WebSocket connected')
    ws.current.onclose = () => console.log('WebSocket disconnected')

    ws.current.onmessage = (e) => {
      const data = JSON.parse(e.data)

      if (data.typing && data.sender_id === userId) {
        setTyping(true)
        setTimeout(() => setTyping(false), 3000)
        return
      }

      setMessages(prev => [
        ...prev,
        {
          content: data.message,
          is_own: data.sender_id === currentUserId,
          sent_at: new Date().toISOString(),
        },
      ])
    }

    return () => ws.current.close()
  }, [userId, currentUserId, token])

  useEffect(scrollToBottom, [messages])

  const handleSend = async () => {
    if (!content.trim()) return

    if (ws.current && ws.current.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify({ message: content }))
    }

    try {
      await sendMessage(userId, content)
    } catch (err) {
      console.error('Failed to persist message via API:', err)
    }

    setMessages(prev => [
      ...prev,
      { content, is_own: true, sent_at: new Date().toISOString() },
    ])
    setContent('')
  }

  const handleTyping = () => {
    if (ws.current && ws.current.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify({ typing: true }))
    }
  }

  return (
    <div className="p-4">
      <h3 className="text-lg font-bold mb-2">Chat with {recipientName}</h3>
      <div className="border rounded h-64 overflow-y-auto p-2 mb-4 bg-gray-50">
        {loading ? (
          <p>Loading...</p>
        ) : messages.length === 0 ? (
          <p className="text-sm text-gray-500">No messages yet. Say hello!</p>
        ) : (
          messages.map((m, i) => (
            <div
              key={i}
              className={`text-sm mb-2 ${m.is_own ? 'text-right' : 'text-left'}`}
            >
              <span className="inline-block bg-white p-2 rounded shadow-sm">
                {m.content}
              </span>
              <p className="text-xs text-gray-400 mt-1">
                {formatDistanceToNow(parseISO(m.sent_at), { addSuffix: true })}
              </p>
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {typing && <p className="text-xs text-gray-500 italic">User is typing...</p>}

      <div className="flex gap-2 mt-2">
        <input
          className="flex-1 border rounded p-2"
          placeholder="Type your message..."
          value={content}
          onChange={e => {
            setContent(e.target.value)
            handleTyping()
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter') handleSend()
          }}
        />
        <button
          className="bg-blue-600 text-white px-4 py-2 rounded"
          onClick={handleSend}
        >
          Send
        </button>
      </div>
    </div>
  )
}

export default MessageThread
